package com.automation.test;

import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * BaseTest class is used to create driver
 */
public class BaseTest {
	//driver name static variable
    public static WebDriver driver;
    static WebDriverWait wait;
    public static String username= "test" + RandomStringUtils.randomAlphanumeric(5) + RandomStringUtils.randomNumeric(6);
    
    @BeforeClass
    public static void beforeClass() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver,10);
    }
    
    @AfterClass
    public static void tearDown() {
        //driver.close();
    }
}