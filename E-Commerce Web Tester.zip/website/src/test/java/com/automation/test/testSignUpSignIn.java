package com.automation.test;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class testSignUpSignIn extends BaseTest{

    @Before
    public void setUp() {
        driver.navigate().to("https://www.demoblaze.com/index.html");
    }

    
    /* 
     * This test method is to sign up a new user
     */
    @Test
    public void SignUpNewUser() {
        if(driver.findElement(By.id("logout2")).isDisplayed())
            driver.findElement(By.id("logout2")).click();
        driver.findElement(By.id("signin2")).click();
        driver.findElement(By.id("sign-username")).sendKeys(username);
        driver.findElement(By.id("sign-password")).sendKeys("password");
        driver.findElement(By.xpath("//button[contains(.,'Sign up')]")).click();
        //Fraction of seconds after alert is popped up, it wont fail
        wait.until(ExpectedConditions.alertIsPresent());
        String signUpAlertText=driver.switchTo().alert().getText();
        driver.switchTo().alert().accept();
        Assert.assertTrue("User is not created successfully",signUpAlertText.contains("Sign up successful."));
    }

    
    
    
    /* 
     * This test method is to verify if user is able to login in and check welcome message
     */
    @Test
    public void LogInUser() {
        driver.findElement(By.id("login2")).click();
        driver.findElement(By.id("loginusername")).sendKeys("testUserForScript");
        driver.findElement(By.id("loginpassword")).sendKeys("password");
        driver.findElement(By.xpath("//button[contains(.,'Log in')]")).click();
        boolean welcomeScreen=driver.findElement(By.xpath("//a[contains(.,'Welcome testUserForScript')]")).isDisplayed();
        Assert.assertTrue("User is able to login and verify his name on the welcome screen",welcomeScreen);
        driver.findElement(By.id("logout2")).click();
        boolean loginScreen=driver.findElement(By.id("login2")).isDisplayed();
        Assert.assertTrue("User is not able to logout and navigated to initial screen",loginScreen);
    }
  
}

