package com.automation.test;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class testWebSiteDetails extends BaseTest{

    @Before
    public void setUp() {
        driver.navigate().to("https://www.demoblaze.com/index.html");
    }

    
    /* 
     * This test method is to verify if user is able to add comments
     */
    @Test
    public void addCommentsAndSendMessage() throws InterruptedException {
        driver.findElement(By.xpath("//a[contains(.,'Contact')]")).click();
        driver.findElement(By.id("recipient-email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("recipient-name")).sendKeys("test");
        driver.findElement(By.id("message-text")).sendKeys("test user comments");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[contains(.,'Send message')]")).click();
        wait.until(ExpectedConditions.alertIsPresent());
        String signUpAlertText=driver.switchTo().alert().getText();
        driver.switchTo().alert().accept();
        Assert.assertTrue("User is not able to add comments and send message",signUpAlertText.contains("Thanks for the message!!"));
    }
    
    
    
    /* 
     * This test method is to verify if user is able to play video under about us section
     */
    @Test
    public void checkAboutUsSection() throws InterruptedException {
        driver.findElement(By.xpath("//a[contains(.,'About us')]")).click();
        driver.findElement(By.xpath("//button[@title='Play Video']")).click();
        boolean aboutScreenModalWindow=driver.findElement(By.xpath("//h5[contains(.,'About us')]")).isDisplayed();
        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@aria-label='Close'])[4]")));
        driver.findElement(By.xpath("(//button[@aria-label='Close'])[4]")).click();
        Assert.assertTrue("User is not able to play video related to about us",aboutScreenModalWindow);
    } 
    
    
    
    /* 
     * This test method is to verify if user is able to add product to cart and then delete 
     */
    @Test
    public void addToCartAndDelete() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='card-block']/h4/a")));
        List<WebElement> productList=driver.findElements(By.xpath("//div[@class='card-block']/h4/a"));
        productList.get(0).click();
        driver.findElement(By.xpath("//a[contains(text(),'Add to cart')]")).click();
        wait.until(ExpectedConditions.alertIsPresent());
        String productAddAlert=driver.switchTo().alert().getText();
        Assert.assertTrue("User is created successfully",productAddAlert.contains("Product added"));
        driver.switchTo().alert().accept();
        driver.findElement(By.xpath("//a[contains(text(),'Cart')]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[contains(.,'Delete')]")).click();
    } 
}

